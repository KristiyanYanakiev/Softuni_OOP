from project.car import Car


class SportsCar(Car):
    def race(self) -> str:
        return "racing..."
    