from project.sports_car import SportsCar

mazerati = SportsCar()

print(mazerati.race())
print(mazerati.move())
