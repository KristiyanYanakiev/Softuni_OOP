from project.child import Child

child = Child("Kris", 20)

print(child.name)