from project.mammal import Mammal
from project.reptile import Reptile


class Lizard(Reptile):
    pass
