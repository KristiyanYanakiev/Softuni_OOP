from project.dog import Dog

hector = Dog()

print(hector.bark())