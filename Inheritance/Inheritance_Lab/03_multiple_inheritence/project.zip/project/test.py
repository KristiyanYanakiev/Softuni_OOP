from project.teacher import Teacher

teacher_one = Teacher()

print(teacher_one.sleep())
print(teacher_one.get_fired())